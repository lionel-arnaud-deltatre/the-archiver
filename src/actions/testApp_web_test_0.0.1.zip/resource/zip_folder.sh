#!/bin/sh

#zip -r output_file_name.zip /path/to/folder
zip -rq $1 $2
